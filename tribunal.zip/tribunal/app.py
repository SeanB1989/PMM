"""Tribunal: win/loss triangulation. Flask app.

Run locally:   python app.py            (http://localhost:5000)
Public demo:   TRIBUNAL_PUBLIC=1 python app.py   (sample data only, no uploads)
"""
import os
import secrets
import threading
from datetime import datetime, timedelta, timezone

from flask import Flask, Response, abort, flash, jsonify, redirect, render_template, request, session, url_for

from modules import db, engine, importer, projects, stats

PUBLIC = os.environ.get("TRIBUNAL_PUBLIC") == "1"
SAMPLE_SEED = 1

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET") or secrets.token_hex(16)
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024
db.init()


# ------------------------------------------------------------------------------------------ helpers
def live_mode():
    return bool(os.environ.get("ANTHROPIC_API_KEY")) and not PUBLIC


@app.context_processor
def inject():
    return {"PUBLIC": PUBLIC, "LIVE": live_mode(), "model": os.environ.get("TRIBUNAL_MODEL", "claude-opus-5-5")}


@app.template_filter("pct")
def pct(x):
    return "–" if x is None else f"{round(x * 100)}%"


@app.template_filter("rate")
def rate(pair):
    k, n = pair
    return stats.fmt_rate(k, n)


def get_project(pid):
    p = db.one("SELECT * FROM projects WHERE id=?", pid)
    if not p:
        abort(404)
    if PUBLIC and pid not in session.get("mine", []):
        abort(403)
    return p


def cleanup_public():
    """Public demo: drop visitor projects older than a day."""
    cutoff = (datetime.now(timezone.utc) - timedelta(days=1)).isoformat(timespec="seconds")
    for p in db.q("SELECT id FROM projects WHERE created_at < ?", cutoff):
        db.delete_project(p["id"])


def step_counts(pid):
    return {
        "review_open": db.one("SELECT count(*) n FROM review_items WHERE project_id=? AND status='open'", pid)["n"],
        "unconfirmed": db.one("SELECT count(*) n FROM documents WHERE project_id=? AND match_confirmed=0", pid)["n"],
    }


# ------------------------------------------------------------------------------------------ home + setup
@app.route("/")
def home():
    if PUBLIC:
        mine = [db.one("SELECT * FROM projects WHERE id=?", i) for i in session.get("mine", [])]
        return render_template("home.html", projects=[p for p in mine if p])
    return render_template("home.html", projects=db.q("SELECT * FROM projects ORDER BY id DESC"))


@app.post("/sample")
def load_sample():
    if PUBLIC:
        cleanup_public()
    pid = projects.load_sample(seed=7)
    session["mine"] = session.get("mine", []) + [pid]
    # Sample files are generated with the deal ID or a close account name; confirm exact ones, leave fuzzy ones for review.
    return redirect(url_for("match", pid=pid))


@app.post("/new")
def new_project():
    if PUBLIC:
        abort(403)
    name = request.form.get("name", "").strip() or "Untitled analysis"
    comps = [c.strip() for c in request.form.get("competitors", "").split(",") if c.strip()]
    pid = projects.create_project(name, comps)
    crm = request.files.get("crm")
    transcripts = [(f.filename, f.read().decode("utf-8", "replace")) for f in request.files.getlist("transcripts") if f.filename]
    notes = [(f.filename, f.read().decode("utf-8", "replace")) for f in request.files.getlist("notes") if f.filename]
    if not crm or not crm.filename:
        db.delete_project(pid)
        flash("Please upload a CRM export (CSV).")
        return redirect(url_for("home"))
    try:
        importer.import_files(pid, crm.read().decode("utf-8", "replace"), transcripts, notes)
    except ValueError as e:
        db.delete_project(pid)
        flash(str(e))
        return redirect(url_for("home"))
    return redirect(url_for("match", pid=pid))


@app.post("/p/<int:pid>/delete")
def delete(pid):
    get_project(pid)
    db.delete_project(pid)
    session["mine"] = [i for i in session.get("mine", []) if i != pid]
    flash("Project and all its data deleted.")
    return redirect(url_for("home"))


# ------------------------------------------------------------------------------------------ sample + match
@app.route("/p/<int:pid>/match", methods=["GET", "POST"])
def match(pid):
    p = get_project(pid)
    if request.method == "POST":
        action = request.form.get("action")
        if action == "sample":
            seed = request.form.get("seed", "").strip()
            importer.draw_sample(pid, int(request.form.get("recent_n", 10)), int(request.form.get("random_won", 5)),
                                 int(request.form.get("random_lost", 5)), int(seed) if seed else None)
            flash("Sample drawn.")
        elif action == "match":
            for key, val in request.form.items():
                if key.startswith("doc_"):
                    doc_id = int(key[4:])
                    if val == "none":
                        db.run("UPDATE documents SET deal_id=NULL, match_method='excluded', match_confirmed=1 WHERE id=? AND project_id=?", doc_id, pid)
                    elif val:
                        db.run("UPDATE documents SET deal_id=?, match_method='confirmed by you', match_confirmed=1 WHERE id=? AND project_id=?",
                               int(val), doc_id, pid)
            flash("Matches saved.")
        elif action == "competitors":
            comps = [c.strip() for c in request.form.get("competitors", "").split(",") if c.strip()]
            db.run("UPDATE projects SET competitors=? WHERE id=?", db.j(comps), pid)
        return redirect(url_for("match", pid=pid))
    deals = db.q("SELECT * FROM deals WHERE project_id=? ORDER BY ext_id", pid)
    docs = db.q("SELECT d.*, de.ext_id, de.account FROM documents d LEFT JOIN deals de ON de.id=d.deal_id WHERE d.project_id=? ORDER BY d.match_confirmed, d.match_score", pid)
    sample = db.q("SELECT sample_set, count(*) n FROM deals WHERE project_id=? AND in_sample=1 GROUP BY 1", pid)
    counts = {"deals": len(deals), "docs": len(docs),
              "by_method": db.q("SELECT match_method, count(*) n FROM documents WHERE project_id=? GROUP BY 1", pid)}
    return render_template("match.html", p=p, deals=deals, docs=docs, sample=sample, counts=counts,
                           competitors=", ".join(db.unj(p["competitors"], [])), steps=step_counts(pid),
                           default_seed=SAMPLE_SEED if p["is_sample"] else "")


@app.post("/p/<int:pid>/run")
def run(pid):
    p = get_project(pid)
    if p["status"] == "running":
        return redirect(url_for("progress", pid=pid))
    if not db.one("SELECT count(*) n FROM deals WHERE project_id=? AND in_sample=1", pid)["n"]:
        flash("Draw a sample first.")
        return redirect(url_for("match", pid=pid))
    force_demo = PUBLIC or request.form.get("demo") == "1"
    db.run("UPDATE projects SET status='running', progress='Starting' WHERE id=?", pid)
    threading.Thread(target=engine.run_analysis, args=(pid, force_demo), daemon=True).start()
    return redirect(url_for("progress", pid=pid))


@app.route("/p/<int:pid>/progress")
def progress(pid):
    return render_template("progress.html", p=get_project(pid), steps=step_counts(pid))


@app.route("/p/<int:pid>/status")
def status(pid):
    p = get_project(pid)
    return jsonify({"status": p["status"], "progress": p["progress"], "error": p["error"]})


# ------------------------------------------------------------------------------------------ deals
def _recon_map(pid):
    out = {}
    for r in db.q("SELECT * FROM reconstructions WHERE project_id=?", pid):
        out.setdefault(r["deal_id"], []).append(r)
    return out


@app.route("/p/<int:pid>/deals")
def deals(pid):
    p = get_project(pid)
    rec = _recon_map(pid)
    rows = []
    for d in db.q("SELECT * FROM deals WHERE project_id=? AND in_sample=1 ORDER BY sample_set, ext_id", pid):
        rs = rec.get(d["id"], [])
        out = next((r for r in rs if r["question"] == "outcome"), None)
        stg = next((r for r in rs if r["question"] == "stage"), None)
        comps = [r for r in rs if r["question"] == "competitor" and engine.effective(r) == "present"]
        rows.append({"d": d, "outcome": out, "stage": stg, "comps": comps,
                     "crm_comps": db.unj(d["crm_competitors"], []),
                     "disagree": bool(out and engine.effective(out) != d["status"]) or any(not db.unj(c["detail"])["in_crm"] for c in comps)})
    return render_template("deals.html", p=p, rows=rows, steps=step_counts(pid))


@app.route("/p/<int:pid>/deal/<int:did>")
def deal(pid, did):
    p = get_project(pid)
    d = db.one("SELECT * FROM deals WHERE id=? AND project_id=?", did, pid) or abort(404)
    recs = [dict(r, detail=db.unj(r["detail"], {})) for r in db.q("SELECT * FROM reconstructions WHERE deal_id=? ORDER BY question, subject", did)]
    docs = db.q("SELECT * FROM documents WHERE deal_id=? AND match_confirmed=1 ORDER BY date", did)
    codes = {}
    for c in db.q("SELECT c.*, t.name theme FROM codes c LEFT JOIN themes t ON t.id=c.theme_id WHERE c.deal_id=?", did):
        codes.setdefault(c["document_id"], []).append(c)
    return render_template("deal.html", p=p, d=d, recs=recs, docs=docs, codes=codes,
                           crm_comps=db.unj(d["crm_competitors"], []), steps=step_counts(pid))


# ------------------------------------------------------------------------------------------ review
@app.route("/p/<int:pid>/review", methods=["GET", "POST"])
def review(pid):
    p = get_project(pid)
    if request.method == "POST":
        item = db.one("SELECT * FROM review_items WHERE id=? AND project_id=?", int(request.form["item"]), pid) or abort(404)
        engine.resolve_review(item["id"], request.form["action"], request.form.get("value"), request.form.get("note", ""))
        return redirect(url_for("review", pid=pid, show=request.args.get("show", "open")) + f"#item-{item['id']}")
    show = request.args.get("show", "open")
    items = []
    sql = "SELECT r.*, d.ext_id, d.account FROM review_items r JOIN deals d ON d.id=r.deal_id WHERE r.project_id=?"
    sql += " AND r.status='open'" if show == "open" else " AND r.status!='open'"
    for it in db.q(sql + " ORDER BY CASE r.kind WHEN 'contested' THEN 0 WHEN 'quote_check' THEN 1 ELSE 2 END, r.id", pid):
        det = db.unj(it["detail"], {})
        evidence = []
        if it["reconstruction_id"]:
            r = db.one("SELECT * FROM reconstructions WHERE id=?", it["reconstruction_id"])
            evidence = db.unj(r["detail"], {})["sources"]
        if it["code_id"]:
            c = db.one("SELECT c.*, doc.text, doc.kind FROM codes c JOIN documents doc ON doc.id=c.document_id WHERE c.id=?", it["code_id"])
            evidence = [{"kind": c["kind"], "value": c["label"], "quote": c["quote"], "timestamp": c["timestamp"], "document_id": c["document_id"]}]
        items.append({"it": it, "det": det, "evidence": evidence})
    return render_template("review.html", p=p, items=items, show=show, steps=step_counts(pid))


# ------------------------------------------------------------------------------------------ findings
def _claims(pid):
    out = []
    for c in db.q("""SELECT c.*, t.name theme, t.description FROM claims c JOIN themes t ON t.id=c.theme_id
                     WHERE c.project_id=? ORDER BY CASE c.status WHEN 'dropped' THEN 1 ELSE 0 END,
                     CASE c.confidence WHEN 'High' THEN 0 WHEN 'Medium' THEN 1 ELSE 2 END, c.id""", pid):
        st = db.unj(c["stats"], {})
        quotes = db.q(f"""SELECT c.quote, c.timestamp, c.deal_id, de.ext_id, doc.kind FROM codes c JOIN deals de ON de.id=c.deal_id
                          JOIN documents doc ON doc.id=c.document_id WHERE c.theme_id=? AND c.quote_verified=1
                          ORDER BY doc.kind DESC, c.id""", c["theme_id"])
        seen, top = set(), []
        support = set(st.get("support", []))
        for q in quotes:
            if q["deal_id"] in support and q["deal_id"] not in seen:
                seen.add(q["deal_id"])
                top.append(q)
        counter_ids = st.get("counter", [])
        counter = db.q(f"SELECT id, ext_id FROM deals WHERE id IN ({','.join('?' * len(counter_ids))})", *counter_ids) if counter_ids else []
        out.append({"c": c, "st": st, "reasons": db.unj(c["reasons"], []), "quotes": top[:3], "more": max(0, len(top) - 3),
                    "counter": counter, "events": db.q("SELECT * FROM claim_events WHERE claim_id=? ORDER BY id", c["id"]),
                    "ci_lost": stats.wilson(*st["in_lost"]), "ci_won": stats.wilson(*st["in_won"])})
    return out


@app.route("/p/<int:pid>/findings", methods=["GET", "POST"])
def findings(pid):
    p = get_project(pid)
    if request.method == "POST":
        cid = int(request.form["claim"])
        db.one("SELECT id FROM claims WHERE id=? AND project_id=?", cid, pid) or abort(404)
        confirm = request.form.get("confirm")
        engine.update_claim(cid, status=request.form.get("status") or None,
                            confirm=None if confirm is None else confirm == "1",
                            statement=request.form.get("statement", "").strip() or None, note=request.form.get("note", "").strip())
        return redirect(url_for("findings", pid=pid) + f"#claim-{cid}")
    if p["status"] != "analysed":
        return redirect(url_for("match", pid=pid))
    usage = db.one("SELECT sum(input_tokens) i, sum(output_tokens) o FROM usage WHERE project_id=?", pid)
    return render_template("findings.html", p=p, h=engine.headline(pid), claims=_claims(pid), usage=usage, steps=step_counts(pid))


# ------------------------------------------------------------------------------------------ report
def _report_data(pid):
    p = get_project(pid)
    return {"p": p, "h": engine.headline(pid), "claims": _claims(pid),
            "sample": db.q("SELECT sample_set, count(*) n FROM deals WHERE project_id=? AND in_sample=1 GROUP BY 1", pid),
            "reviewed": db.one("SELECT count(*) n FROM review_items WHERE project_id=? AND status!='open'", pid)["n"],
            "open": db.one("SELECT count(*) n FROM review_items WHERE project_id=? AND status='open'", pid)["n"],
            "generated": datetime.now().strftime("%d %b %Y")}


@app.route("/p/<int:pid>/report")
def report(pid):
    return render_template("report.html", steps=step_counts(pid), **_report_data(pid))


@app.route("/p/<int:pid>/report.md")
def report_md(pid):
    data = _report_data(pid)
    md = render_template("report.md.j2", **data)
    name = "".join(ch if ch.isalnum() else "-" for ch in data["p"]["name"].lower()).strip("-")
    return Response(md, mimetype="text/markdown", headers={"Content-Disposition": f"attachment; filename=tribunal-{name}.md"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)

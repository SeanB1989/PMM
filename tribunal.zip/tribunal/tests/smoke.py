"""Quick manual check: python -m tests.smoke [seed]"""
import os
import sys
import tempfile

os.environ.setdefault("TRIBUNAL_DB", os.path.join(tempfile.mkdtemp(), "smoke.db"))
from modules import db, engine, importer, projects  # noqa: E402

db.init()
pid = projects.load_sample()
db.run("UPDATE documents SET match_confirmed=1 WHERE deal_id IS NOT NULL")
seed = int(sys.argv[1]) if len(sys.argv) > 1 else 42
print("sample size", importer.draw_sample(pid, 10, 5, 5, seed=seed))
engine.run_analysis(pid, force_demo=True)
p = db.one("SELECT * FROM projects WHERE id=?", pid)
print(p["status"], p["error"][:500])
for c in db.q("SELECT * FROM claims WHERE project_id=?", pid):
    st = db.unj(c["stats"])
    print(f"{c['confidence']:6} lost {st['in_lost']} won {st['in_won']}  {c['statement']}")
h = engine.headline(pid)
print("CRM open but evidence closed:", h["crm_open_but_closed"], "| competitive flagged:", h["competitive_rate"])
for r in h["rows"]:
    print(f"  {r['name']:11} CRM {r['crm_rate']:32} evidence {r['ev_rate']:32} proven={r['proven']} needed={r['needed']}")
print([tuple(r) for r in db.q("SELECT kind, count(*) FROM review_items WHERE project_id=? GROUP BY 1", pid)])

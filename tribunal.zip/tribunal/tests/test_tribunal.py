import os
import re
import tempfile

os.environ["TRIBUNAL_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")
os.environ.pop("ANTHROPIC_API_KEY", None)

import pytest  # noqa: E402

from modules import db, engine, importer, projects, sample_data, stats  # noqa: E402

db.init()


# ------------------------------------------------------------------ stats
def test_wilson_matches_known_value():
    p, lo, hi = stats.wilson(6, 20)
    assert p == 0.3
    assert round(lo, 2) == 0.16 and round(hi, 2) == 0.48


def test_wilson_edges():
    assert stats.wilson(0, 0) == (None, None, None)
    p, lo, hi = stats.wilson(0, 5)
    assert p == 0 and lo == 0 and hi > 0.3
    p, lo, hi = stats.wilson(5, 5)
    assert hi == 1 and lo < 0.7


def test_deals_needed_shrinks_intervals():
    need = stats.deals_needed(9, 10, 3, 10)
    assert need is None or need >= 20
    assert stats.deals_needed(5, 10, 5, 10) is None


# ------------------------------------------------------------------ import + matching
def test_crm_parsing_handles_aliases():
    csv_text = "Deal ID,Company,Deal Stage,Primary Competitor\nX-1,Acme,Closed Won,Globex; Initech\nX-2,Beta,Closed Lost,\n"
    deals = importer.parse_crm(csv_text)
    assert deals[0]["status"] == "won" and deals[0]["crm_competitors"] == ["Globex", "Initech"]
    assert deals[1]["status"] == "lost"


def test_vtt_parsing_keeps_timestamps():
    vtt = "WEBVTT\n\n1\n00:01:05.000 --> 00:01:09.000\nDana: We chose Globex.\n"
    meta, text = importer.parse_transcript("acme-call.vtt", vtt)
    assert "[01:05] Dana: We chose Globex." in text


def test_quote_verification():
    text = "[02:10] Buyer (Acme): Honestly it's been rough. Our IT team can’t expose an API.\n"
    ok, ts = engine.verify_quote("Our IT team can't expose an API", text)
    assert ok and ts == "02:10"
    ok, _ = engine.verify_quote("They loved the product", text)
    assert not ok


# ------------------------------------------------------------------ full loop on the sample company
@pytest.fixture(scope="module")
def analysed():
    pid = projects.load_sample(seed=7)
    pending = db.one("SELECT count(*) n FROM documents WHERE project_id=? AND match_confirmed=0", pid)["n"]
    assert pending > 0, "sample should include some fuzzy matches for the user to confirm"
    db.run("UPDATE documents SET match_confirmed=1 WHERE project_id=? AND deal_id IS NOT NULL", pid)
    seed, n = importer.draw_sample(pid, 10, 5, 5, seed=1)
    assert n == 20
    engine.run_analysis(pid, force_demo=True)
    assert db.one("SELECT status FROM projects WHERE id=?", pid)["status"] == "analysed"
    return pid


def test_sampling_is_reproducible(analysed):
    other = projects.load_sample(seed=7)
    importer.draw_sample(other, 10, 5, 5, seed=1)
    a = {r["ext_id"] for r in db.q("SELECT ext_id FROM deals WHERE project_id=? AND in_sample=1", analysed)}
    b = {r["ext_id"] for r in db.q("SELECT ext_id FROM deals WHERE project_id=? AND in_sample=1", other)}
    assert a == b


def test_finds_crm_undercounting_competitors(analysed):
    h = engine.headline(analysed)
    assert h["competitive_ev"] > h["competitive_crm_flagged"] * 1.5


def test_finds_stale_open_deals(analysed):
    assert engine.headline(analysed)["crm_open_but_closed"] >= 1
    assert db.one("SELECT count(*) n FROM review_items WHERE project_id=? AND kind='contested'", analysed)["n"] >= 1


def _claim(pid, pattern):
    for c in db.q("SELECT * FROM claims WHERE project_id=?", pid):
        if re.search(pattern, c["statement"], re.I):
            return c
    return None


def test_finds_planted_patterns(analysed):
    legacy = _claim(analysed, "legacy|on-prem")
    reseller = _claim(analysed, "reseller")
    se = _claim(analysed, "solutions engineer")
    for c in (legacy, reseller, se):
        assert c is not None
    assert db.unj(legacy["stats"])["direction"] == "loss" and legacy["confidence"] in ("Medium", "High")
    assert db.unj(se["stats"])["direction"] == "win" and se["confidence"] in ("Medium", "High")
    assert len(db.unj(legacy["stats"])["counter"]) >= 1, "the planted counter-example should show up"


def test_docufy_gap_direction(analysed):
    row = next(r for r in engine.headline(analysed)["rows"] if r["name"] == "Docufy")
    assert row["ev_present"] > row["crm_flagged"]


def test_every_counted_quote_is_real(analysed):
    for c in db.q("SELECT c.quote, d.text FROM codes c JOIN documents d ON d.id=c.document_id WHERE c.project_id=? AND c.quote_verified=1", analysed):
        assert engine._norm(c["quote"]).strip(" .") in engine._norm(c["text"])


def test_high_confidence_requires_a_person(analysed):
    assert not db.q("SELECT id FROM claims WHERE project_id=? AND confidence='High' AND human_confirmed=0", analysed)
    se = _claim(analysed, "solutions engineer")
    engine.update_claim(se["id"], confirm=True, note="checked 3 calls")
    se2 = db.one("SELECT * FROM claims WHERE id=?", se["id"])
    assert se2["confidence"] == "High"
    kinds = [e["kind"] for e in db.q("SELECT kind FROM claim_events WHERE claim_id=?", se["id"])]
    assert "confirmed" in kinds


def test_review_resolution_updates_claims(analysed):
    item = db.one("SELECT * FROM review_items WHERE project_id=? AND kind='contested' AND status='open'", analysed)
    engine.resolve_review(item["id"], "confirm", note="listened to the call")
    r = db.one("SELECT * FROM reconstructions WHERE id=?", item["reconstruction_id"])
    assert r["human_value"] == db.unj(item["detail"])["suggested"]
    assert db.one("SELECT status FROM review_items WHERE id=?", item["id"])["status"] == "confirmed"


# ------------------------------------------------------------------ web screens
def test_all_screens_render(analysed):
    import app as web
    web.app.config["TESTING"] = True
    c = web.app.test_client()
    did = db.one("SELECT id FROM deals WHERE project_id=? AND in_sample=1", analysed)["id"]
    for path in ["/", f"/p/{analysed}/match", f"/p/{analysed}/deals", f"/p/{analysed}/deal/{did}",
                 f"/p/{analysed}/review", f"/p/{analysed}/review?show=done", f"/p/{analysed}/findings",
                 f"/p/{analysed}/report", f"/p/{analysed}/report.md"]:
        r = c.get(path)
        assert r.status_code == 200, path
    md = c.get(f"/p/{analysed}/report.md").get_data(as_text=True)
    assert "## Claims" in md and "Docufy" in md


def test_generator_is_fictional():
    files, truth = sample_data.generate(7)
    assert len(truth) == 40 and "crm_export.csv" in files
    assert not any("sanas" in v.lower() for v in files.values())


# ------------------------------------------------------------------ Claude path, with a fake API client
class _Block:
    type = "text"

    def __init__(self, text):
        self.text = text


class _Msg:
    def __init__(self, text):
        self.content = [_Block(text)]
        self.usage = type("U", (), {"input_tokens": 100, "output_tokens": 50})()


class _FakeClient:
    def __init__(self, replies):
        self.replies = list(replies)
        self.prompts = []
        self.messages = self

    def create(self, **kw):
        self.prompts.append(kw["messages"][0]["content"])
        return _Msg(self.replies.pop(0))


def test_claude_analyst_parses_and_cleans():
    from modules.analyst import ClaudeAnalyst
    a = ClaudeAnalyst.__new__(ClaudeAnalyst)
    a.model, a.name, a.usage = "test-model", "Claude (test-model)", [0, 0]
    a.client = _FakeClient([
        'Here you go:\n```json\n{"codes": [{"label": "IT cannot expose API", "quote": "Our IT team can\'t expose an API"}],'
        ' "outcome": {"value": "open", "quote": ""}, "competitors": [{"name": "docufy", "quote": "we chose Docufy"}],'
        ' "stage": {"value": "nonsense", "quote": ""}}\n```',
        '{"themes": [{"name": "Legacy blocks POC", "claim": "x", "direction": "loss", "code_ids": [1]}]}',
    ])
    r = a.code_document("text {with braces}", "transcript", ["Docufy"])
    assert r["codes"][0]["label"] == "IT cannot expose API"
    assert r["stage"]["value"] == "unknown"  # invalid values are cleaned
    assert "text {with braces}" in a.client.prompts[0]
    assert a.theme([{"id": 1, "label": "IT cannot expose API", "quote": "q"}])[0]["direction"] == "loss"
    assert a.usage == [200, 100]

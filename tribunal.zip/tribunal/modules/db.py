"""SQLite storage. One file, every project, code, quote and decision saved."""
import json
import os
import sqlite3
import threading
from datetime import datetime, timezone

DB_PATH = os.environ.get("TRIBUNAL_DB", os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "tribunal.db"))

_local = threading.local()

SCHEMA = """
CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    created_at TEXT NOT NULL,
    is_sample INTEGER DEFAULT 0,
    competitors TEXT DEFAULT '[]',
    seed INTEGER,
    recent_n INTEGER DEFAULT 10,
    random_won INTEGER DEFAULT 5,
    random_lost INTEGER DEFAULT 5,
    status TEXT DEFAULT 'new',          -- new | imported | sampled | running | analysed | error
    progress TEXT DEFAULT '',
    error TEXT DEFAULT '',
    analyst TEXT DEFAULT ''             -- 'claude:<model>' or 'demo'
);
CREATE TABLE IF NOT EXISTS deals (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL,
    ext_id TEXT, account TEXT, stage TEXT, status TEXT, amount REAL,
    close_date TEXT, owner TEXT, crm_competitors TEXT DEFAULT '[]', loss_reason TEXT,
    in_sample INTEGER DEFAULT 0, sample_set TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL,
    kind TEXT NOT NULL,                  -- transcript | note
    filename TEXT, deal_ref TEXT, account_ref TEXT, date TEXT, author TEXT, text TEXT,
    deal_id INTEGER, match_method TEXT, match_score REAL, match_confirmed INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS codes (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL, document_id INTEGER, deal_id INTEGER,
    label TEXT, quote TEXT, quote_verified INTEGER DEFAULT 0, timestamp TEXT, theme_id INTEGER
);
CREATE TABLE IF NOT EXISTS verdicts (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL, deal_id INTEGER, source_kind TEXT, document_id INTEGER,
    question TEXT, value TEXT, quote TEXT, timestamp TEXT
);
CREATE TABLE IF NOT EXISTS reconstructions (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL, deal_id INTEGER, question TEXT, subject TEXT DEFAULT '',
    value TEXT, level TEXT, detail TEXT DEFAULT '{}', human_value TEXT, human_note TEXT
);
CREATE TABLE IF NOT EXISTS themes (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL, name TEXT, description TEXT, claim TEXT, direction TEXT
);
CREATE TABLE IF NOT EXISTS claims (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL, theme_id INTEGER, statement TEXT,
    status TEXT DEFAULT 'holding', confidence TEXT, reasons TEXT, stats TEXT DEFAULT '{}',
    human_confirmed INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS claim_events (
    id INTEGER PRIMARY KEY,
    claim_id INTEGER, at TEXT, actor TEXT, kind TEXT, note TEXT
);
CREATE TABLE IF NOT EXISTS review_items (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL, kind TEXT, deal_id INTEGER, reconstruction_id INTEGER, code_id INTEGER,
    title TEXT, detail TEXT DEFAULT '{}', status TEXT DEFAULT 'open', resolution TEXT, note TEXT
);
CREATE TABLE IF NOT EXISTS usage (
    id INTEGER PRIMARY KEY,
    project_id INTEGER, input_tokens INTEGER, output_tokens INTEGER
);
"""


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def conn():
    c = getattr(_local, "conn", None)
    if c is None:
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        c = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=30)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        _local.conn = c
    return c


def init():
    conn().executescript(SCHEMA)
    conn().commit()


def q(sql, *args):
    return conn().execute(sql, args).fetchall()


def one(sql, *args):
    return conn().execute(sql, args).fetchone()


def run(sql, *args):
    cur = conn().execute(sql, args)
    conn().commit()
    return cur.lastrowid


def many(sql, rows):
    conn().executemany(sql, rows)
    conn().commit()


def j(value):
    return json.dumps(value)


def unj(value, default=None):
    if value in (None, ""):
        return default
    return json.loads(value)


ANALYSIS_TABLES = ["codes", "verdicts", "reconstructions", "themes", "review_items", "usage"]


def clear_analysis(project_id):
    for t in ANALYSIS_TABLES:
        conn().execute(f"DELETE FROM {t} WHERE project_id=?", (project_id,))
    conn().execute("DELETE FROM claim_events WHERE claim_id IN (SELECT id FROM claims WHERE project_id=?)", (project_id,))
    conn().execute("DELETE FROM claims WHERE project_id=?", (project_id,))
    conn().commit()


def delete_project(project_id):
    clear_analysis(project_id)
    for t in ["documents", "deals", "projects"]:
        col = "id" if t == "projects" else "project_id"
        conn().execute(f"DELETE FROM {t} WHERE {col}=?", (project_id,))
    conn().commit()


def set_progress(project_id, text, status=None):
    if status:
        run("UPDATE projects SET progress=?, status=? WHERE id=?", text, status, project_id)
    else:
        run("UPDATE projects SET progress=? WHERE id=?", text, project_id)

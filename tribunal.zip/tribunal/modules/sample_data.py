"""Fictional sample company with planted patterns.

Company: Parsely, AI document extraction for insurance and lending operations.
Competitors: Docufy (main), ClaimStack, Inkwell AI. Resellers: Meridian Partners, Apex Channel.

Planted patterns (the tool should find all of them):
  1. The CRM under-records competitors (field filled on only ~1/3 of competitive deals).
  2. Several lost deals are still "open" in the CRM, and most losses have no loss reason.
  3. POCs fail when the prospect's systems are legacy / on-prem with no API access. These are
     mostly losses to Docufy, with one counter-example win.
  4. Resellers quote below Parsely's list price, and some deals are lost on that.
  5. Wins cluster where a solutions engineer is involved early.

Everything here is invented. No real company, person or deal.
"""
import csv
import io
import random
from datetime import date, timedelta

COMPANY = "Parsely"
COMPETITORS = ["Docufy", "ClaimStack", "Inkwell AI"]
RESELLERS = ["Meridian Partners", "Apex Channel"]

_PREFIX = ["Harbor", "Bluestone", "Cedar", "Northgate", "Ironwood", "Silverline", "Keystone", "Maple", "Summit",
           "Riverbend", "Oakridge", "Beacon", "Granite", "Lakeshore", "Pinecrest", "Redwood", "Stonebridge",
           "Westfield", "Brightwater", "Copperhill"]
_SUFFIX = ["Mutual", "Lending", "Insurance", "Credit Union", "Assurance", "Financial"]
_FIRST = ["Priya", "Marcus", "Dana", "Tomas", "Leah", "Owen", "Grace", "Rafael", "Mei", "Jonah", "Nadia", "Victor"]
_LAST = ["Okafor", "Lindqvist", "Reyes", "Chen", "Patel", "Morrison", "Haddad", "Novak", "Brennan", "Sato"]
_REPS = ["Alex Rivera", "Sam Whitfield", "Jordan Blake", "Casey Moreno"]
_SES = ["Nina Kowalski", "Ravi Menon"]


def _ts(sec):
    return f"[{sec // 60:02d}:{sec % 60:02d}]"


class _Call:
    def __init__(self, rng, rep, buyer, account):
        self.rng, self.rep, self.buyer, self.account = rng, rep, buyer, account
        self.sec = rng.randint(5, 40)
        self.lines = []

    def say(self, who, text):
        name = f"{self.rep} ({COMPANY})" if who == "rep" else f"{self.buyer} ({self.account})"
        self.lines.append(f"{_ts(self.sec)} {name}: {text}")
        self.sec += self.rng.randint(20, 140)

    def text(self, header):
        return header + "\n\n" + "\n".join(self.lines) + "\n"


def generate(seed=7, n_deals=40):
    """Return (files, truth). files maps filename -> text content, exactly as a user would upload."""
    rng = random.Random(seed)
    accounts = []
    combos = [(p, s) for p in _PREFIX for s in _SUFFIX]
    rng.shuffle(combos)
    for p, s in combos[:n_deals]:
        accounts.append(f"{p} {s}")

    # Hidden truth per deal
    # Fixed mix of outcomes and drivers so the planted patterns always exist; order is shuffled.
    plan = ([("won", "early_se")] * 10 + [("won", "accuracy")] * 4 +
            [("lost", "tech_fit")] * 9 + [("lost", "reseller_price")] * 5 +
            [("lost", "champion_change")] * 3 + [("lost", "price")] * 1)
    plan += [("open", None)] * (n_deals - len(plan))
    rng.shuffle(plan)
    truth = []
    start = date(2026, 1, 12)
    for i in range(n_deals):
        outcome, driver = plan[i]
        # Who shows up depends on how the deal went: Docufy mostly beats us on legacy-system POCs
        comps = []
        if driver == "tech_fit":
            comps = ["Docufy" if rng.random() < 0.85 else "ClaimStack"]
        elif outcome == "lost" and driver != "reseller_price" and rng.random() < 0.7:
            comps = ["Docufy" if rng.random() < 0.6 else rng.choice(COMPETITORS[1:])]
        elif outcome == "won" and rng.random() < 0.7:
            comps = ["Docufy" if rng.random() < 0.3 else rng.choice(COMPETITORS[1:])]
        elif outcome == "open" and rng.random() < 0.6:
            comps = [rng.choice(COMPETITORS)]
        if comps and rng.random() < 0.25:
            comps.append(rng.choice([c for c in COMPETITORS if c not in comps]))
        truth.append({
            "ext_id": f"OPP-{1001 + i}",
            "account": accounts[i],
            "outcome": outcome,
            "competitors": comps,
            "driver": driver,
            "reseller": rng.choice(RESELLERS),
            "rep": rng.choice(_REPS),
            "buyer": f"{rng.choice(_FIRST)} {rng.choice(_LAST)}",
            "amount": rng.choice([48, 60, 72, 90, 120, 150, 180, 240]) * 1000,
            "date": start + timedelta(days=int(i * 5.5) + rng.randint(0, 4)),
        })
    # One counter-example: a won deal that also hit the legacy-systems problem
    for t in truth:
        if t["outcome"] == "won":
            t["also_tech_issue"] = True
            break

    files = {}
    # ---- CRM export (corrupted) ----
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["Opportunity ID", "Account Name", "Stage", "Amount", "Close Date", "Owner", "Competitor", "Loss Reason"])
    stale = sorted([t for t in truth if t["outcome"] == "lost" and t["driver"] in ("tech_fit", "reseller_price")],
                   key=lambda t: t["date"], reverse=True)
    left_open_ids = {t["ext_id"] for t in stale[:4]}  # the most recent losses were never closed out in the CRM
    for t in truth:
        crm_comp = ""
        # Reps log the competitor when they win, and rarely when they lose
        flag_rate = {"won": 0.6, "lost": 0.12, "open": 0.3}[t["outcome"]]
        if t["competitors"] and rng.random() < flag_rate:
            crm_comp = t["competitors"][0]
        loss_reason = ""
        if t["outcome"] == "won":
            stage = "Closed Won"
        elif t["outcome"] == "lost":
            if t["ext_id"] in left_open_ids:
                stage = rng.choice(["Proof of Concept", "Negotiation"])
            else:
                stage = "Closed Lost"
                if rng.random() < 0.4:
                    loss_reason = rng.choice(["Price", "No decision", "Other"])
        else:
            stage = rng.choice(["Discovery", "Proof of Concept", "Negotiation"])
        close = t["date"].isoformat() if stage.startswith("Closed") else ""
        w.writerow([t["ext_id"], t["account"], stage, t["amount"], close, t["rep"], crm_comp, loss_reason])
        t["crm_stage"] = stage
        t["crm_competitor"] = crm_comp
    files["crm_export.csv"] = out.getvalue()

    # ---- Transcripts ----
    notes = []
    variant_counter = [0]
    for t in truth:
        acct_label = t["account"]
        use_id = rng.random() > 0.2  # ~20% of files only name the account, sometimes spelled differently
        if not use_id:
            variant_counter[0] += 1
            acct_label = ([
                t["account"].upper(),
                t["account"] + " Group",
                t["account"].replace("Insurance", "Ins.").replace("Credit Union", "CU").replace("Financial", "Fin.")
                .replace("Assurance", "Assur.").replace("Lending", "Lend.").replace("Mutual", "Mut."),
                _typo(rng, t["account"]),  # a misspelling: needs a person to confirm
                t["account"],
            ])[variant_counter[0] % 5]
        calls = _calls_for(rng, t)
        for k, (title, call) in enumerate(calls):
            d = t["date"] - timedelta(days=(len(calls) - k) * 9)
            header = f"Title: {title}\nAccount: {acct_label}\nDate: {d.isoformat()}"
            if use_id:
                header = f"Deal: {t['ext_id']}\n" + header
                fname = f"{t['ext_id']}_{k + 1}_{title.lower().replace(' ', '_')}.txt"
            else:
                fname = f"{acct_label.lower().replace(' ', '-')}_{k + 1}.txt"
            files[f"transcripts/{fname}"] = call.text(header)
        notes.extend(_notes_for(rng, t))

    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["Deal ID", "Account", "Author", "Date", "Note"])
    for n in notes:
        w.writerow(n)
    files["field_notes.csv"] = out.getvalue()
    return files, truth


def _typo(rng, name):
    first, _, rest = name.partition(" ")
    i = rng.randint(1, len(first) - 2)
    return first[:i] + first[i + 1] + first[i] + first[i + 2:] + " " + rest


def _calls_for(rng, t):
    comps = t["competitors"]
    main = comps[0] if comps else None
    calls = []

    # Discovery
    c = _Call(rng, t["rep"], t["buyer"], t["account"])
    c.say("rep", f"Thanks for making time. Can you walk me through how documents come into {t['account']} today?")
    c.say("buyer", rng.choice([
        "Mostly scanned PDFs and email attachments. The team keys a lot of it by hand.",
        "Claims forms come in through three channels and we re-key most of them.",
        "Loan packets arrive as PDFs, and our ops team spends hours on data entry every day."]))
    if main:
        c.say("buyer", f"To be transparent, we're also talking to {main}.")
    if len(comps) > 1:
        c.say("buyer", f"And {comps[1]} reached out as well, so we'll see a few demos.")
    if t["driver"] == "early_se" or (t["outcome"] == "won" and rng.random() < 0.3):
        c.say("rep", f"I've brought our solutions engineer, {rng.choice(_SES)}, onto this first call so we can map your intake flow and systems now.")
        c.say("buyer", "That's helpful. Having the technical call early saves us weeks.")
    if t["driver"] == "tech_fit" or t.get("also_tech_issue"):
        c.say("buyer", "Our core claims platform is on-prem, a legacy mainframe system. We'll figure out integration later.")
    c.say("rep", "Great. Next step would be a short proof of concept on your own documents.")
    calls.append(("Discovery call", c))

    # POC check-in for anything that got that far
    if t["outcome"] in ("won", "lost") or rng.random() < 0.5:
        c = _Call(rng, t["rep"], t["buyer"], t["account"])
        c.say("rep", "How is the POC going on your side?")
        if t["driver"] == "tech_fit" or t.get("also_tech_issue"):
            c.say("buyer", "Honestly it's been rough. Our IT team can't expose an API from the mainframe, so the pilot only runs on exported files.")
            c.say("buyer", "Without a live integration it's hard to prove the time savings.")
            if t["driver"] == "tech_fit" and main:
                c.say("buyer", f"{main} offered to run their POC on the exports and hand us a batch connector, which made it easier for IT.")
        elif t["driver"] == "accuracy":
            c.say("buyer", "The extraction accuracy has been impressive, well above what we measured in our last tool.")
        elif t["driver"] == "early_se":
            c.say("buyer", "Your SE had the connector running in the first week, so the team is already using it.")
        else:
            c.say("buyer", "It's going fine. The results look reasonable so far.")
        if t["driver"] == "reseller_price":
            c.say("buyer", f"One awkward thing. {t['reseller']} quoted us your product at a lower price than your list price.")
            c.say("rep", "Let me look into that. That quote shouldn't be below our pricing.")
        if t["driver"] == "price":
            c.say("buyer", "The pricing is the sticking point. It's more than we budgeted.")
        if t["driver"] == "champion_change":
            c.say("buyer", "Heads up, there's been a reorg and our new VP wants to revisit all tooling decisions.")
        calls.append(("POC check-in", c))

    # Final call for closed deals
    if t["outcome"] in ("won", "lost"):
        c = _Call(rng, t["rep"], t["buyer"], t["account"])
        c.say("rep", "Thanks for jumping on. Where did you land?")
        if t["outcome"] == "won":
            c.say("buyer", rng.choice([
                "We're moving forward with you. Legal has the order form and we've signed it.",
                "Good news, we signed. We're excited to partner with Parsely."]))
        else:
            if t["driver"] == "tech_fit" and main:
                c.say("buyer", f"We've decided to go with {main}. Their approach worked with our legacy systems.")
            elif t["driver"] == "reseller_price":
                c.say("buyer", f"We're going to buy through {t['reseller']}. Their price was simply cheaper for the same product.")
            elif t["driver"] == "champion_change":
                c.say("buyer", "We're not moving forward this year. The new VP paused the project.")
            else:
                pick = main or "another vendor"
                c.say("buyer", f"We decided to go with {pick}. It came down to price.")
        calls.append(("Final call", c))
    return calls


def _notes_for(rng, t):
    rows = []
    se = rng.choice(_SES)
    d = (t["date"] - timedelta(days=6)).isoformat()
    if t["driver"] == "tech_fit" or t.get("also_tech_issue"):
        rows.append([t["ext_id"], t["account"], se, d,
                     "POC blocked: customer's claims system is on-prem mainframe with no API access. Could only test on exported PDFs; could not show end-to-end time savings."])
    if t["driver"] == "early_se":
        rows.append([t["ext_id"], t["account"], se, d,
                     "SE joined discovery. Mapped intake flow and systems in week one; connector live before POC kickoff."])
    if t["driver"] == "reseller_price":
        rows.append([t["ext_id"], t["account"], t["rep"], d,
                     f"Customer has a quote from {t['reseller']} below our list price. Partner bought wholesale last year."])
    if t["competitors"] and rng.random() < 0.5:
        rows.append([t["ext_id"] if rng.random() < 0.8 else "", t["account"], se, d,
                     f"Competitive: {', '.join(t['competitors'])} in the deal."])
    return rows

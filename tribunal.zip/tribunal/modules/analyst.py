"""The analyst: reads documents and writes open codes + verdicts, then groups codes into themes.

ClaudeAnalyst calls the Anthropic API. DemoAnalyst is a transparent, rule-based stand-in used when no
API key is set (and on the public demo). Both return exactly the same shapes, so the rest of the app
does not care which one ran.
"""
import json
import os
import re

OUTCOMES = ["won", "lost", "open", "unknown"]
STAGES = ["discovery", "demo", "poc", "security", "pricing", "procurement", "unknown"]

CODE_PROMPT = """You are a qualitative researcher doing open coding (grounded theory) on B2B sales evidence.

Read the {kind} below from one sales deal. Do NOT use a preset list of tags. Write short, specific codes
(3 to 8 words) that describe what is actually happening, each grounded in an exact quote.

Also give your verdicts on three questions, each with the exact quote that supports it:
- outcome: did this deal end "won", "lost", or is it still "open"? Use "unknown" if this document does not say.
- competitors: which competing vendors are present in the deal? Known competitors: {competitors}. Include others if named.
  Do not list resellers or partners selling the seller's own product as competitors.
- stage: where was the deal won or lost? One of: discovery, demo, poc, security, pricing, procurement, unknown.

Rules:
- Quotes must be copied VERBATIM from the text, max 30 words, no ellipses.
- Skip small talk. 3 to 8 codes is typical.
- If the document is silent on a question, say "unknown" with an empty quote. Never guess.

Respond with JSON only, in exactly this shape:
{{"codes": [{{"label": "...", "quote": "..."}}],
  "outcome": {{"value": "won|lost|open|unknown", "quote": "..."}},
  "competitors": [{{"name": "...", "quote": "..."}}],
  "stage": {{"value": "...", "quote": "..."}}}}

<{kind}>
{text}
</{kind}>"""

THEME_PROMPT = """You are a qualitative researcher. Below are open codes from calls and notes across many B2B sales
deals (id | code | quote). Group codes that describe the same underlying pattern into themes.

For each theme give:
- name: 3 to 7 words
- description: one sentence
- claim: a single testable claim a sales leader could act on, e.g. "We lose POCs when the prospect's core system has no API"
- direction: "loss" if the pattern should drive losses, "win" if it should drive wins, "neutral" otherwise
- code_ids: the ids of the codes in the theme

Rules: each code in at most one theme. Drop codes that are small talk or say nothing about why deals are won or
lost. Prefer 4 to 10 themes. Respond with JSON only: {{"themes": [{{"name": "...", "description": "...",
"claim": "...", "direction": "loss|win|neutral", "code_ids": [1, 2]}}]}}

CODES:
{codes}"""


def _extract_json(text):
    text = text.strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.M).strip()
    start = text.find("{")
    end = text.rfind("}")
    return json.loads(text[start:end + 1])


class ClaudeAnalyst:
    def __init__(self, api_key=None, model=None):
        import anthropic
        self.client = anthropic.Anthropic(api_key=api_key or os.environ["ANTHROPIC_API_KEY"])
        self.model = model or os.environ.get("TRIBUNAL_MODEL", "claude-opus-5-5")
        self.name = f"Claude ({self.model})"
        self.usage = [0, 0]

    def _ask(self, prompt, max_tokens):
        last_err = None
        for _ in range(2):
            msg = self.client.messages.create(model=self.model, max_tokens=max_tokens,
                                              messages=[{"role": "user", "content": prompt}])
            self.usage[0] += msg.usage.input_tokens
            self.usage[1] += msg.usage.output_tokens
            try:
                return _extract_json("".join(b.text for b in msg.content if b.type == "text"))
            except (ValueError, json.JSONDecodeError) as e:
                last_err = e
        raise RuntimeError(f"Claude did not return valid JSON: {last_err}")

    def code_document(self, text, kind, competitors):
        return _clean_coding(self._ask(CODE_PROMPT.format(kind="call transcript" if kind == "transcript" else "field note",
                                                          competitors=", ".join(competitors) or "none given",
                                                          text=text[:60000]), 3000))

    def theme(self, codes):
        lines = "\n".join(f"{c['id']} | {c['label']} | {c['quote'][:160]}" for c in codes)
        data = self._ask(THEME_PROMPT.format(codes=lines), 8000)
        return data.get("themes", [])


def _clean_coding(d):
    out = {"codes": [], "competitors": []}
    for c in d.get("codes", []) or []:
        if c.get("label") and c.get("quote"):
            out["codes"].append({"label": c["label"].strip(), "quote": c["quote"].strip()})
    o = d.get("outcome") or {}
    out["outcome"] = {"value": o.get("value", "unknown") if o.get("value") in OUTCOMES else "unknown", "quote": o.get("quote", "")}
    s = d.get("stage") or {}
    out["stage"] = {"value": s.get("value", "unknown") if s.get("value") in STAGES else "unknown", "quote": s.get("quote", "")}
    for c in d.get("competitors", []) or []:
        if c.get("name"):
            out["competitors"].append({"name": c["name"].strip(), "quote": c.get("quote", "")})
    return out


# --------------------------------------------------------------------------------------------------
# Demo analyst: keyword rules. Transparent and deterministic; good enough to show the method on the
# sample company. It is labelled as a stand-in everywhere it is used.
# --------------------------------------------------------------------------------------------------
DEMO_RULES = [
    ("Legacy system with no API blocks POC", "loss",
     r"mainframe|on-prem|no api|can't expose an api|legacy systems?|only runs on exported|only test on exported"),
    ("Reseller quoting below list price", "loss",
     r"quoted us your product at a lower price|below (?:our|your) list price|buy through|bought wholesale|price was simply cheaper"),
    ("Price above budget", "loss", r"more than we budgeted|came down to price|pricing is the sticking point"),
    ("Champion change or reorg stalls deal", "loss", r"reorg|new vp"),
    ("Early solutions engineer involvement", "win",
     r"solutions engineer|technical call early|se joined discovery|your se had the connector|connector live before"),
    ("Strong extraction accuracy in POC", "win", r"accuracy has been impressive|extraction accuracy"),
    ("Competitor offers easier integration path", "loss", r"offered to run their poc|batch connector|worked with our legacy"),
    ("Heavy manual data entry today", "neutral", r"re-key|keys a lot of it by hand|hours on data entry"),
]
DEMO_THEME_TEXT = {
    "Legacy system with no API blocks POC": ("Our POCs fail when the prospect's core system is legacy or on-prem with no API access.",
                                             "Prospects on legacy or on-prem systems can't connect us, so the POC can't prove value."),
    "Reseller quoting below list price": ("Resellers undercut our own list price, and we lose deals to our own channel.",
                                          "Channel partners quote the product below list price."),
    "Price above budget": ("Price above budget costs us deals.", "Buyers say the price is above budget."),
    "Champion change or reorg stalls deal": ("Champion changes and reorgs stall deals late.", "A reorg or new leader pauses the project."),
    "Early solutions engineer involvement": ("We win when a solutions engineer joins at discovery.",
                                             "An SE on the first call maps systems early and speeds the POC."),
    "Strong extraction accuracy in POC": ("Proven accuracy in the POC wins deals.", "Buyers praise extraction accuracy during the POC."),
    "Competitor offers easier integration path": ("Competitors win by making integration easier for IT.",
                                                  "Competitors offer workarounds that suit legacy systems."),
}


def _sentences(text):
    for line in text.splitlines():
        body = re.sub(r"^\[\d+:\d+\]\s*[^:]{1,80}:\s*", "", line).strip()
        for s in re.split(r"(?<=[.!?])\s+", body):
            if s.strip():
                yield s.strip()


class DemoAnalyst:
    name = "Demo analyst (rule-based stand-in for Claude)"

    def __init__(self):
        self.usage = [0, 0]

    def code_document(self, text, kind, competitors):
        codes, comps, outcome, stage = [], [], {"value": "unknown", "quote": ""}, {"value": "unknown", "quote": ""}
        seen = set()
        for s in _sentences(text):
            low = s.lower()
            for label, _, pat in DEMO_RULES:
                if re.search(pat, low) and (label, s) not in seen:
                    seen.add((label, s))
                    codes.append({"label": label, "quote": s})
            for c in competitors:
                if c.lower() in low and c not in [x["name"] for x in comps]:
                    comps.append({"name": c, "quote": s})
            if re.search(r"we've signed|we signed|moving forward with you|excited to partner", low):
                outcome = {"value": "won", "quote": s}
            elif re.search(r"decided to go with|going to buy through|not moving forward", low):
                outcome = {"value": "lost", "quote": s}
        labels = {c["label"] for c in codes}
        if outcome["value"] == "lost" or "Legacy system with no API blocks POC" in labels:
            if "Legacy system with no API blocks POC" in labels:
                q = next(c["quote"] for c in codes if c["label"] == "Legacy system with no API blocks POC")
                stage = {"value": "poc", "quote": q}
            elif labels & {"Reseller quoting below list price", "Price above budget"}:
                q = next(c["quote"] for c in codes if c["label"] in ("Reseller quoting below list price", "Price above budget"))
                stage = {"value": "pricing", "quote": q}
        return {"codes": codes, "competitors": comps, "outcome": outcome, "stage": stage}

    def theme(self, codes):
        groups = {}
        for c in codes:
            groups.setdefault(c["label"], []).append(c["id"])
        out = []
        for label, direction, _ in DEMO_RULES:
            if label in groups and direction != "neutral":
                claim, desc = DEMO_THEME_TEXT[label]
                out.append({"name": label, "description": desc, "claim": claim, "direction": direction, "code_ids": groups[label]})
        return out


def get_analyst(force_demo=False):
    if not force_demo and os.environ.get("ANTHROPIC_API_KEY"):
        return ClaudeAnalyst()
    return DemoAnalyst()

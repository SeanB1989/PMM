"""Small, checkable statistics. No libraries needed."""
import math

Z90 = 1.6449


def wilson(k, n, z=Z90):
    """Wilson score interval for k successes out of n. Returns (point, low, high) as fractions."""
    if n <= 0:
        return (None, None, None)
    p = k / n
    z2 = z * z
    denom = 1 + z2 / n
    centre = (p + z2 / (2 * n)) / denom
    margin = z * math.sqrt(p * (1 - p) / n + z2 / (4 * n * n)) / denom
    return (p, max(0.0, centre - margin), min(1.0, centre + margin))


def fmt_rate(k, n):
    """'30% (likely 16–48%), 6 of 20'"""
    p, lo, hi = wilson(k, n)
    if p is None:
        return "no data"
    return f"{round(p * 100)}% (likely {round(lo * 100)}–{round(hi * 100)}%), {k} of {n}"


def overlap(a, b):
    return not (a[2] < b[1] or b[2] < a[1])


def deals_needed(k1, n1, k2, n2, max_mult=40):
    """How many deals (total of both groups) before the gap would stop overlapping, if the rates held.
    Returns None if the rates are identical or it would take more than max_mult times the current sample."""
    if n1 == 0 or n2 == 0 or k1 / n1 == k2 / n2:
        return None
    for m in range(1, max_mult + 1):
        if not overlap(wilson(k1 * m, n1 * m), wilson(k2 * m, n2 * m)):
            return (n1 + n2) * m
    return None

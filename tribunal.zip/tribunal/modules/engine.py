"""The pipeline: code -> theme -> reconstruct -> review queue -> claims.

Confidence is counted from evidence with visible rules. The model never rates its own certainty.
"""
import re
import traceback
from concurrent.futures import ThreadPoolExecutor

from . import db, stats
from .analyst import get_analyst

RELIABILITY = {"transcript": 3, "note": 2, "crm": 1}
KIND_LABEL = {"transcript": "calls", "note": "notes", "crm": "CRM"}
LOSS_REASON_STAGE = {"price": "pricing", "pricing": "pricing", "security": "security", "procurement": "procurement",
                     "technical": "poc", "poc": "poc", "product fit": "poc"}


# ------------------------------------------------------------------------------------------ helpers
def _norm(s):
    s = (s or "").lower().replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    return re.sub(r"\s+", " ", s).strip()


def verify_quote(quote, text):
    """True if the quote really appears in the source. Returns (verified, timestamp)."""
    nq = _norm(quote).strip(" .\"'")
    if not nq:
        return False, ""
    if nq not in _norm(text):
        return False, ""
    probe = nq[:40]
    for line in text.splitlines():
        if probe in _norm(line):
            m = re.match(r"^\[(\d+:\d+)\]", line.strip())
            return True, (m.group(1) if m else "")
    return True, ""


def canonical_competitor(name, known):
    for k in known:
        if _norm(k) == _norm(name) or _norm(k) in _norm(name):
            return k
    return name.strip()


# ------------------------------------------------------------------------------------------ pipeline
def run_analysis(project_id, force_demo=False):
    try:
        _run(project_id, force_demo)
    except Exception as e:  # surfaced on screen, never swallowed
        db.run("UPDATE projects SET status='error', error=?, progress='' WHERE id=?",
               f"{e}\n\n{traceback.format_exc()[-1500:]}", project_id)


def _run(project_id, force_demo):
    project = db.one("SELECT * FROM projects WHERE id=?", project_id)
    known = db.unj(project["competitors"], [])
    analyst = get_analyst(force_demo=force_demo)
    db.clear_analysis(project_id)
    db.run("UPDATE projects SET status='running', error='', analyst=? WHERE id=?", analyst.name, project_id)

    deals = db.q("SELECT * FROM deals WHERE project_id=? AND in_sample=1", project_id)
    deal_ids = [d["id"] for d in deals]
    if not deal_ids:
        raise RuntimeError("No deals in the sample. Draw a sample first.")
    marks = ",".join("?" * len(deal_ids))
    docs = db.q(f"SELECT * FROM documents WHERE project_id=? AND deal_id IN ({marks}) AND match_confirmed=1", project_id, *deal_ids)

    # 1. CRM verdicts
    for d in deals:
        db.run("INSERT INTO verdicts (project_id, deal_id, source_kind, question, value, quote) VALUES (?,?,?,?,?,?)",
               project_id, d["id"], "crm", "outcome", d["status"], f"CRM stage: {d['stage'] or 'blank'}")
        for c in db.unj(d["crm_competitors"], []):
            db.run("INSERT INTO verdicts (project_id, deal_id, source_kind, question, value, quote) VALUES (?,?,?,?,?,?)",
                   project_id, d["id"], "crm", "competitor", canonical_competitor(c, known), f"CRM competitor field: {c}")
        lr = (d["loss_reason"] or "").lower()
        stage = next((v for k, v in LOSS_REASON_STAGE.items() if k in lr), None)
        if stage:
            db.run("INSERT INTO verdicts (project_id, deal_id, source_kind, question, value, quote) VALUES (?,?,?,?,?,?)",
                   project_id, d["id"], "crm", "stage", stage, f"CRM loss reason: {d['loss_reason']}")

    # 2. Open coding, one document at a time
    total = len(docs)
    done = [0]

    def work(doc):
        result = analyst.code_document(doc["text"], doc["kind"], known)
        done[0] += 1
        db.set_progress(project_id, f"Coding documents with {analyst.name}: {done[0]} of {total}")
        return doc, result

    workers = 4 if analyst.name.startswith("Claude") else 1
    with ThreadPoolExecutor(max_workers=workers) as pool:
        results = list(pool.map(work, docs))

    for doc, r in results:
        for c in r["codes"]:
            ok, ts = verify_quote(c["quote"], doc["text"])
            db.run("INSERT INTO codes (project_id, document_id, deal_id, label, quote, quote_verified, timestamp) VALUES (?,?,?,?,?,?,?)",
                   project_id, doc["id"], doc["deal_id"], c["label"], c["quote"], int(ok), ts)
        for question in ("outcome", "stage"):
            v = r[question]
            value = v["value"]
            if question == "outcome" and value == "open":
                value = "unknown"  # a single call only captures a moment; "still open" is not evidence of the end state
            if value != "unknown":
                _, ts = verify_quote(v["quote"], doc["text"])
                db.run("INSERT INTO verdicts (project_id, deal_id, source_kind, document_id, question, value, quote, timestamp) VALUES (?,?,?,?,?,?,?,?)",
                       project_id, doc["deal_id"], doc["kind"], doc["id"], question, value, v["quote"], ts)
        for c in r["competitors"]:
            _, ts = verify_quote(c["quote"], doc["text"])
            db.run("INSERT INTO verdicts (project_id, deal_id, source_kind, document_id, question, value, quote, timestamp) VALUES (?,?,?,?,?,?,?,?)",
                   project_id, doc["deal_id"], doc["kind"], doc["id"], "competitor", canonical_competitor(c["name"], known), c["quote"], ts)

    # 3. Themes across all codes
    db.set_progress(project_id, f"Grouping codes into themes with {analyst.name}")
    codes = [dict(c) for c in db.q("SELECT id, label, quote FROM codes WHERE project_id=?", project_id)]
    valid_ids = {c["id"] for c in codes}
    for t in analyst.theme(codes) if codes else []:
        tid = db.run("INSERT INTO themes (project_id, name, description, claim, direction) VALUES (?,?,?,?,?)",
                     project_id, t.get("name", "Unnamed theme"), t.get("description", ""), t.get("claim", t.get("name", "")),
                     t.get("direction", "neutral") if t.get("direction") in ("loss", "win", "neutral") else "neutral")
        for cid in t.get("code_ids", []):
            if cid in valid_ids:
                db.run("UPDATE codes SET theme_id=? WHERE id=? AND theme_id IS NULL", tid, cid)

    # 4. Reconstruct each deal, 5. review queue, 6. claims
    db.set_progress(project_id, "Reconstructing deals and scoring claims")
    for d in deals:
        reconstruct_deal(project_id, d["id"], known)
    build_review_queue(project_id)
    compute_claims(project_id)

    if analyst.usage[0]:
        db.run("INSERT INTO usage (project_id, input_tokens, output_tokens) VALUES (?,?,?)", project_id, *analyst.usage)
    db.set_progress(project_id, "", status="analysed")


# ------------------------------------------------------------------------------------------ reconstruction
def _level(values_by_kind):
    """values_by_kind: {kind: value} for sources that were not silent."""
    distinct = set(values_by_kind.values())
    if len(distinct) > 1:
        return "contested"
    if len(values_by_kind) >= 2:
        return "strong"
    kind = next(iter(values_by_kind))
    return "moderate" if kind == "transcript" else "weak"


def _latest_by_kind(rows):
    """Latest non-silent verdict per source kind (documents ordered by date)."""
    out = {}
    for r in rows:
        out[r["source_kind"]] = r  # rows arrive oldest first, so later ones win
    return out


def reconstruct_deal(project_id, deal_id, known):
    rows = db.q("""SELECT v.*, COALESCE(doc.date, '') AS ddate FROM verdicts v LEFT JOIN documents doc ON doc.id = v.document_id
                   WHERE v.project_id=? AND v.deal_id=? ORDER BY ddate, v.id""", project_id, deal_id)
    for question in ("outcome", "stage"):
        qrows = [r for r in rows if r["question"] == question]
        latest = _latest_by_kind(qrows)
        if not latest:
            continue
        values = {k: r["value"] for k, r in latest.items()}
        level = _level(values)
        best = max(latest, key=lambda k: RELIABILITY[k])
        detail = {"sources": [{"kind": k, "value": r["value"], "quote": r["quote"], "timestamp": r["timestamp"],
                               "document_id": r["document_id"]} for k, r in latest.items()]}
        db.run("INSERT INTO reconstructions (project_id, deal_id, question, value, level, detail) VALUES (?,?,?,?,?,?)",
               project_id, deal_id, question, values[best], level, db.j(detail))
    # competitors: silence is not contradiction
    comp_rows = [r for r in rows if r["question"] == "competitor"]
    names = sorted({r["value"] for r in comp_rows})
    for name in names:
        by_kind = {}
        for r in comp_rows:
            if r["value"] == name:
                by_kind.setdefault(r["source_kind"], r)
        level = _level({k: "present" for k in by_kind})
        detail = {"sources": [{"kind": k, "value": "present", "quote": r["quote"], "timestamp": r["timestamp"],
                               "document_id": r["document_id"]} for k, r in by_kind.items()],
                  "in_crm": "crm" in by_kind}
        db.run("INSERT INTO reconstructions (project_id, deal_id, question, subject, value, level, detail) VALUES (?,?,?,?,?,?,?)",
               project_id, deal_id, "competitor", name, "present", level, db.j(detail))


def effective(r):
    return r["human_value"] if r["human_value"] else r["value"]


# ------------------------------------------------------------------------------------------ review queue
def build_review_queue(project_id):
    deals = {d["id"]: d for d in db.q("SELECT * FROM deals WHERE project_id=?", project_id)}
    for r in db.q("SELECT * FROM reconstructions WHERE project_id=? AND level='contested'", project_id):
        d = deals[r["deal_id"]]
        det = db.unj(r["detail"], {})
        says = "; ".join(f"{KIND_LABEL[s['kind']]} say{'s' if s['kind'] == 'crm' else ''} {s['value']}" for s in det["sources"])
        db.run("INSERT INTO review_items (project_id, kind, deal_id, reconstruction_id, title, detail) VALUES (?,?,?,?,?,?)",
               project_id, "contested", d["id"], r["id"], f"{d['ext_id']} {r['question']}: {says}",
               db.j({"options": sorted({s['value'] for s in det['sources']}), "suggested": r["value"]}))
    for r in db.q("SELECT * FROM reconstructions WHERE project_id=? AND question='competitor'", project_id):
        det = db.unj(r["detail"], {})
        if not det.get("in_crm"):
            d = deals[r["deal_id"]]
            db.run("INSERT INTO review_items (project_id, kind, deal_id, reconstruction_id, title, detail) VALUES (?,?,?,?,?,?)",
                   project_id, "crm_gap", d["id"], r["id"], f"{d['ext_id']}: {r['subject']} is in the deal but not in the CRM",
                   db.j({"options": ["present", "absent"], "suggested": "present"}))
    for c in db.q("SELECT * FROM codes WHERE project_id=? AND quote_verified=0 AND theme_id IS NOT NULL", project_id):
        d = deals[c["deal_id"]]
        db.run("INSERT INTO review_items (project_id, kind, deal_id, code_id, title, detail) VALUES (?,?,?,?,?,?)",
               project_id, "quote_check", d["id"], c["id"], f"{d['ext_id']}: quote not found word-for-word in the source",
               db.j({"options": ["keep", "discard"], "suggested": "discard"}))


def resolve_review(item_id, action, value=None, note=""):
    """action: confirm | reject | edit."""
    item = db.one("SELECT * FROM review_items WHERE id=?", item_id)
    det = db.unj(item["detail"], {})
    if item["kind"] in ("contested", "crm_gap"):
        r = db.one("SELECT * FROM reconstructions WHERE id=?", item["reconstruction_id"])
        if action == "confirm":
            chosen = det.get("suggested")
        elif action == "reject":
            if item["kind"] == "crm_gap":
                chosen = "absent"
            else:
                crm = next((s["value"] for s in db.unj(r["detail"], {})["sources"] if s["kind"] == "crm"), None)
                chosen = crm or "unknown"
        else:
            chosen = value
        db.run("UPDATE reconstructions SET human_value=?, human_note=? WHERE id=?", chosen, note, r["id"])
        resolution = chosen
    else:  # quote_check
        keep = action == "confirm" or (action == "edit" and value == "keep")
        if not keep:
            db.run("UPDATE codes SET theme_id=NULL WHERE id=?", item["code_id"])
        resolution = "keep" if keep else "discard"
    status = {"confirm": "confirmed", "reject": "rejected", "edit": "edited"}[action]
    db.run("UPDATE review_items SET status=?, resolution=?, note=? WHERE id=?", status, resolution, note, item_id)
    compute_claims(item["project_id"])


# ------------------------------------------------------------------------------------------ claims
def deal_outcomes(project_id):
    out = {}
    for r in db.q("SELECT * FROM reconstructions WHERE project_id=? AND question='outcome'", project_id):
        out[r["deal_id"]] = effective(r)
    return out


def confidence_for(n_support, n_strong, n_counter, n_kinds, human, direction_ok):
    ratio = n_counter / (n_support + n_counter) if (n_support + n_counter) else 1
    reasons = [f"{n_support} deal{'s' if n_support != 1 else ''} support it ({n_strong} with strong evidence)",
               f"{n_counter} counter-example{'s' if n_counter != 1 else ''}",
               f"{n_kinds} source type{'s' if n_kinds != 1 else ''}",
               "confirmed by you" if human else "not yet confirmed by a person"]
    if not direction_ok:
        reasons.append("the deals point the other way from the claim")
        return "Low", reasons
    high = n_support >= 5 and n_strong >= 3 and ratio <= 0.2 and n_kinds >= 2
    if high and human:
        return "High", reasons
    if n_support >= 3 and ratio <= 0.34:
        if high:
            reasons.append("would be High once confirmed")
        return "Medium", reasons
    return "Low", reasons


def compute_claims(project_id):
    outcomes = deal_outcomes(project_id)
    lost = {d for d, v in outcomes.items() if v == "lost"}
    won = {d for d, v in outcomes.items() if v == "won"}
    existing = {c["theme_id"]: c for c in db.q("SELECT * FROM claims WHERE project_id=?", project_id)}
    for t in db.q("SELECT * FROM themes WHERE project_id=?", project_id):
        rows = db.q("""SELECT c.deal_id, d.kind, c.document_id FROM codes c JOIN documents d ON d.id=c.document_id
                       WHERE c.theme_id=?""", t["id"])
        per_deal = {}
        for r in rows:
            per_deal.setdefault(r["deal_id"], {"kinds": set(), "docs": set()})
            per_deal[r["deal_id"]]["kinds"].add(r["kind"])
            per_deal[r["deal_id"]]["docs"].add(r["document_id"])
        deals_with = set(per_deal)
        direction = t["direction"]
        target, other = (lost, won) if direction != "win" else (won, lost)
        support = deals_with & target
        counter = deals_with & other
        strong = [d for d in support if len(per_deal[d]["kinds"]) >= 2 or len(per_deal[d]["docs"]) >= 2]
        kinds = set().union(*[per_deal[d]["kinds"] for d in support]) if support else set()
        in_lost, in_won = len(deals_with & lost), len(deals_with & won)
        rate_lost = in_lost / len(lost) if lost else 0
        rate_won = in_won / len(won) if won else 0
        if direction == "neutral":
            direction_ok = True
        else:
            direction_ok = (rate_lost > rate_won) if direction == "loss" else (rate_won > rate_lost)
        prev = existing.get(t["id"])
        human = bool(prev and prev["human_confirmed"])
        conf, reasons = confidence_for(len(support), len(strong), len(counter), len(kinds), human, direction_ok)
        st = {"support": sorted(support), "counter": sorted(counter), "strong": sorted(strong),
              "kinds": sorted(kinds), "in_lost": [in_lost, len(lost)], "in_won": [in_won, len(won)],
              "direction": direction, "direction_ok": direction_ok, "all_deals": sorted(deals_with)}
        if prev:
            db.run("UPDATE claims SET confidence=?, reasons=?, stats=? WHERE id=?", conf, db.j(reasons), db.j(st), prev["id"])
        else:
            cid = db.run("INSERT INTO claims (project_id, theme_id, statement, confidence, reasons, stats) VALUES (?,?,?,?,?,?)",
                         project_id, t["id"], t["claim"] or t["name"], conf, db.j(reasons), db.j(st))
            db.run("INSERT INTO claim_events (claim_id, at, actor, kind, note) VALUES (?,?,?,?,?)",
                   cid, db.now(), "Tribunal", "created", f"From theme: {t['name']}")


def update_claim(claim_id, status=None, confirm=None, statement=None, note="", actor="You"):
    c = db.one("SELECT * FROM claims WHERE id=?", claim_id)
    if statement and statement != c["statement"]:
        db.run("UPDATE claims SET statement=? WHERE id=?", statement, claim_id)
        db.run("INSERT INTO claim_events (claim_id, at, actor, kind, note) VALUES (?,?,?,?,?)",
               claim_id, db.now(), actor, "reworded", note or f"Was: {c['statement']}")
        if not status:
            status = "revised"
    if status and status != c["status"]:
        db.run("UPDATE claims SET status=? WHERE id=?", status, claim_id)
        db.run("INSERT INTO claim_events (claim_id, at, actor, kind, note) VALUES (?,?,?,?,?)",
               claim_id, db.now(), actor, f"marked {status}", note)
    if confirm is not None and bool(confirm) != bool(c["human_confirmed"]):
        db.run("UPDATE claims SET human_confirmed=? WHERE id=?", int(confirm), claim_id)
        db.run("INSERT INTO claim_events (claim_id, at, actor, kind, note) VALUES (?,?,?,?,?)",
               claim_id, db.now(), actor, "confirmed" if confirm else "unconfirmed", note)
    compute_claims(c["project_id"])


# ------------------------------------------------------------------------------------------ headline
def headline(project_id):
    """CRM version vs evidenced version, per competitor."""
    project = db.one("SELECT * FROM projects WHERE id=?", project_id)
    deals = {d["id"]: d for d in db.q("SELECT * FROM deals WHERE project_id=? AND in_sample=1", project_id)}
    outcomes = deal_outcomes(project_id)
    comp = {}
    for r in db.q("SELECT * FROM reconstructions WHERE project_id=? AND question='competitor'", project_id):
        if effective(r) == "present":
            comp.setdefault(r["subject"], set()).add(r["deal_id"])
    names = list(dict.fromkeys(db.unj(project["competitors"], []) + sorted(comp)))
    rows = []
    for name in names:
        crm_deals = {i for i, d in deals.items() if name in db.unj(d["crm_competitors"], [])}
        crm_closed = [i for i in crm_deals if deals[i]["status"] in ("won", "lost")]
        crm_won = sum(1 for i in crm_closed if deals[i]["status"] == "won")
        ev_deals = comp.get(name, set())
        ev_closed = [i for i in ev_deals if outcomes.get(i) in ("won", "lost")]
        ev_won = sum(1 for i in ev_closed if outcomes.get(i) == "won")
        if not crm_deals and not ev_deals:
            continue
        a, b = stats.wilson(crm_won, len(crm_closed)), stats.wilson(ev_won, len(ev_closed))
        proven = None
        needed = None
        if len(crm_closed) and len(ev_closed):
            proven = not stats.overlap(a, b)
            if not proven:
                needed = stats.deals_needed(crm_won, len(crm_closed), ev_won, len(ev_closed))
        rows.append({"name": name, "crm_flagged": len(crm_deals), "ev_present": len(ev_deals),
                     "crm_rate": stats.fmt_rate(crm_won, len(crm_closed)), "ev_rate": stats.fmt_rate(ev_won, len(ev_closed)),
                     "crm_k": crm_won, "crm_n": len(crm_closed), "ev_k": ev_won, "ev_n": len(ev_closed),
                     "crm_ci": a, "ev_ci": b, "proven": proven, "needed": needed})
    crm_open_but_closed = sum(1 for i, d in deals.items() if d["status"] == "open" and outcomes.get(i) in ("won", "lost"))
    competitive_ev = set().union(*comp.values()) if comp else set()
    competitive_crm = {i for i, d in deals.items() if db.unj(d["crm_competitors"], [])}
    return {"rows": rows, "sample": len(deals), "crm_open_but_closed": crm_open_but_closed,
            "competitive_ev": len(competitive_ev), "competitive_crm_flagged": len(competitive_crm & competitive_ev),
            "competitive_rate": stats.fmt_rate(len(competitive_crm & competitive_ev), len(competitive_ev))}

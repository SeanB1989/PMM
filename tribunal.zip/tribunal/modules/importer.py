"""Parse uploads (CRM CSV, transcripts, field notes), match documents to deals, and draw the sample."""
import csv
import io
import random
import re
from difflib import SequenceMatcher

from . import db

CRM_ALIASES = {
    "ext_id": ["opportunity id", "opportunity_id", "deal id", "deal_id", "id", "opp id", "record id"],
    "account": ["account name", "account", "company", "company name", "account_name"],
    "stage": ["stage", "stagename", "deal stage", "stage name"],
    "status": ["status", "outcome", "won/lost", "result"],
    "amount": ["amount", "value", "deal value", "acv", "arr"],
    "close_date": ["close date", "closedate", "close_date", "closed date"],
    "owner": ["owner", "opportunity owner", "deal owner", "rep"],
    "competitor": ["competitor", "competitors", "primary competitor", "main competitor"],
    "loss_reason": ["loss reason", "closed lost reason", "loss_reason", "reason lost"],
}
NOTE_ALIASES = {
    "deal_ref": ["deal id", "deal_id", "opportunity id", "opportunity_id", "id"],
    "account_ref": ["account", "account name", "company"],
    "author": ["author", "by", "engineer", "owner"],
    "date": ["date", "created", "created date"],
    "text": ["note", "notes", "text", "body", "content"],
}


def _map_headers(headers, aliases):
    lower = {h.strip().lower(): h for h in headers}
    return {field: next((lower[a] for a in names if a in lower), None) for field, names in aliases.items()}


def normalise_status(stage, status):
    s = f"{status or ''} {stage or ''}".lower()
    if "won" in s or s.strip() in ("true", "1", "yes"):
        return "won"
    if "lost" in s or "false" in s:
        return "lost"
    return "open"


def parse_crm(text):
    reader = csv.DictReader(io.StringIO(text))
    m = _map_headers(reader.fieldnames or [], CRM_ALIASES)
    if not m["ext_id"] and not m["account"]:
        raise ValueError("CRM file needs at least a deal ID or account name column.")
    deals = []
    for i, row in enumerate(reader):
        get = lambda f: (row.get(m[f]) or "").strip() if m[f] else ""
        comps = [c.strip() for c in re.split(r"[;,/]", get("competitor")) if c.strip()]
        try:
            amount = float(re.sub(r"[^\d.]", "", get("amount")) or 0)
        except ValueError:
            amount = 0
        deals.append({
            "ext_id": get("ext_id") or f"ROW-{i + 1}",
            "account": get("account"),
            "stage": get("stage"),
            "status": normalise_status(get("stage"), get("status")),
            "amount": amount,
            "close_date": get("close_date"),
            "owner": get("owner"),
            "crm_competitors": comps,
            "loss_reason": get("loss_reason"),
        })
    return deals


_VTT_TIME = re.compile(r"^(\d{2}):(\d{2}):(\d{2})\.\d{3}\s+-->")


def parse_transcript(filename, text):
    """Accepts .txt (optionally with 'Deal:', 'Account:', 'Date:' header lines) or .vtt."""
    meta = {"deal_ref": "", "account_ref": "", "date": "", "author": ""}
    if filename.lower().endswith(".vtt"):
        lines, stamp = [], ""
        for line in text.splitlines():
            line = line.strip()
            mt = _VTT_TIME.match(line)
            if mt:
                h, mi, s = map(int, mt.groups())
                stamp = f"[{h * 60 + mi:02d}:{s:02d}]"
            elif line and line != "WEBVTT" and not line.isdigit():
                lines.append(f"{stamp} {line}" if stamp else line)
        text = "\n".join(lines)
    for line in text.splitlines()[:8]:
        k, _, v = line.partition(":")
        k = k.strip().lower()
        if k in ("deal", "deal id", "opportunity", "opportunity id"):
            meta["deal_ref"] = v.strip()
        elif k in ("account", "company"):
            meta["account_ref"] = v.strip()
        elif k == "date":
            meta["date"] = v.strip()
    if not meta["deal_ref"]:
        mt = re.search(r"(OPP-\d+|[A-Z]{2,5}-\d{3,})", filename)
        if mt:
            meta["deal_ref"] = mt.group(1)
    if not meta["account_ref"]:
        base = re.sub(r"\.[a-z]+$", "", filename.split("/")[-1])
        base = re.sub(r"[_-]\d+$", "", base)
        meta["account_ref"] = base.replace("-", " ").replace("_", " ")
    return meta, text


def parse_notes(filename, text):
    if filename.lower().endswith(".csv"):
        reader = csv.DictReader(io.StringIO(text))
        m = _map_headers(reader.fieldnames or [], NOTE_ALIASES)
        if not m["text"]:
            raise ValueError("Notes CSV needs a 'Note' or 'Text' column.")
        out = []
        for row in reader:
            get = lambda f: (row.get(m[f]) or "").strip() if m[f] else ""
            out.append(({"deal_ref": get("deal_ref"), "account_ref": get("account_ref"),
                         "author": get("author"), "date": get("date")}, get("text")))
        return out
    meta, body = parse_transcript(filename, text)
    return [(meta, body)]


def import_files(project_id, crm_text=None, transcripts=(), notes=()):
    """transcripts / notes: iterables of (filename, text)."""
    if crm_text:
        db.run("DELETE FROM deals WHERE project_id=?", project_id)
        db.many("INSERT INTO deals (project_id, ext_id, account, stage, status, amount, close_date, owner, crm_competitors, loss_reason)"
                " VALUES (?,?,?,?,?,?,?,?,?,?)",
                [(project_id, d["ext_id"], d["account"], d["stage"], d["status"], d["amount"], d["close_date"],
                  d["owner"], db.j(d["crm_competitors"]), d["loss_reason"]) for d in parse_crm(crm_text)])
    rows = []
    for fname, text in transcripts:
        meta, body = parse_transcript(fname, text)
        rows.append((project_id, "transcript", fname, meta["deal_ref"], meta["account_ref"], meta["date"], "", body))
    for fname, text in notes:
        for meta, body in parse_notes(fname, text):
            if body:
                rows.append((project_id, "note", fname, meta["deal_ref"], meta["account_ref"], meta["date"], meta["author"], body))
    db.many("INSERT INTO documents (project_id, kind, filename, deal_ref, account_ref, date, author, text) VALUES (?,?,?,?,?,?,?,?)", rows)
    match_documents(project_id)
    db.run("UPDATE projects SET status='imported' WHERE id=?", project_id)


_STOP = {"inc", "inc.", "llc", "ltd", "group", "corp", "co", "the"}


_ABBREV = {"cu": "credit union", "ins": "insurance", "fin": "financial", "assur": "assurance", "lend": "lending",
           "mut": "mutual", "intl": "international", "natl": "national", "svcs": "services", "mgmt": "management",
           "tech": "technologies", "bk": "bank"}


def _norm_account(s):
    words = re.sub(r"[^a-z0-9 ]", " ", (s or "").lower()).split()
    return " ".join(_ABBREV.get(w, w) for w in words if w not in _STOP)


def match_documents(project_id):
    deals = db.q("SELECT id, ext_id, account FROM deals WHERE project_id=?", project_id)
    by_id = {d["ext_id"].lower(): d["id"] for d in deals if d["ext_id"]}
    accts = [(d["id"], _norm_account(d["account"])) for d in deals]
    for doc in db.q("SELECT * FROM documents WHERE project_id=? AND match_confirmed=0", project_id):
        ref = (doc["deal_ref"] or "").lower()
        if ref and ref in by_id:
            db.run("UPDATE documents SET deal_id=?, match_method='deal ID', match_score=1, match_confirmed=1 WHERE id=?", by_id[ref], doc["id"])
            continue
        target = _norm_account(doc["account_ref"])
        best, score = None, 0.0
        for did, name in accts:
            s = 1.0 if name and name == target else SequenceMatcher(None, name, target).ratio()
            if s > score:
                best, score = did, s
        if score >= 0.6:
            confirmed = 1 if score == 1.0 else 0  # only exact matches skip a human check
            db.run("UPDATE documents SET deal_id=?, match_method='account name', match_score=?, match_confirmed=? WHERE id=?",
                   best, round(score, 2), confirmed, doc["id"])
        else:
            db.run("UPDATE documents SET deal_id=NULL, match_method='unmatched', match_score=?, match_confirmed=0 WHERE id=?",
                   round(score, 2), doc["id"])


def last_activity(deal, docs):
    dates = [deal["close_date"] or ""] + [d["date"] or "" for d in docs]
    return max(dates)


def draw_sample(project_id, recent_n, random_won, random_lost, seed=None):
    """Two sets: the N most recent deals, plus a random balanced set of CRM-won and CRM-lost deals."""
    seed = seed if seed is not None else random.randint(1, 999999)
    deals = db.q("SELECT * FROM deals WHERE project_id=?", project_id)
    docs = db.q("SELECT deal_id, date FROM documents WHERE project_id=? AND deal_id IS NOT NULL", project_id)
    by_deal = {}
    for d in docs:
        by_deal.setdefault(d["deal_id"], []).append(d)
    with_evidence = [d for d in deals if by_deal.get(d["id"])]
    ranked = sorted(with_evidence, key=lambda d: last_activity(d, by_deal.get(d["id"], [])), reverse=True)
    recent = ranked[:recent_n]
    chosen = {d["id"]: "recent" for d in recent}
    rng = random.Random(seed)
    rest = [d for d in with_evidence if d["id"] not in chosen]
    won = sorted([d for d in rest if d["status"] == "won"], key=lambda d: d["id"])
    lost = sorted([d for d in rest if d["status"] == "lost"], key=lambda d: d["id"])
    for d in rng.sample(won, min(random_won, len(won))):
        chosen[d["id"]] = "random won"
    for d in rng.sample(lost, min(random_lost, len(lost))):
        chosen[d["id"]] = "random lost"
    db.clear_analysis(project_id)  # a new sample invalidates the old analysis
    db.run("UPDATE deals SET in_sample=0, sample_set='' WHERE project_id=?", project_id)
    for did, s in chosen.items():
        db.run("UPDATE deals SET in_sample=1, sample_set=? WHERE id=?", s, did)
    db.run("UPDATE projects SET seed=?, recent_n=?, random_won=?, random_lost=?, status='sampled' WHERE id=?",
           seed, recent_n, random_won, random_lost, project_id)
    return seed, len(chosen)

"""Project-level helpers shared by the web app and tests."""
from . import db, importer, sample_data


def create_project(name, competitors=(), is_sample=False):
    return db.run("INSERT INTO projects (name, created_at, is_sample, competitors) VALUES (?,?,?,?)",
                  name, db.now(), int(is_sample), db.j(list(competitors)))


def load_sample(seed=7):
    files, _truth = sample_data.generate(seed=seed)
    pid = create_project("Sample company: Parsely", sample_data.COMPETITORS, is_sample=True)
    importer.import_files(
        pid,
        crm_text=files["crm_export.csv"],
        transcripts=[(k, v) for k, v in files.items() if k.startswith("transcripts/")],
        notes=[("field_notes.csv", files["field_notes.csv"])],
    )
    return pid

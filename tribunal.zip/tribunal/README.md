# Tribunal

**Your CRM is lying about who you lose to.**

Tribunal rebuilds what really happened in your deals from three messy sources: the CRM, call transcripts and field notes. It then tells you what it found, how sure it is, and what would change its mind.

It's the second tool in this repo, after Vantage. Vantage researches competitors from the outside. Tribunal looks inside your own deals.

## How it works

| Step | What happens |
| --- | --- |
| 1. Sample | The N most recent deals, plus a random balanced set of CRM wins and losses. The seed is saved, so the sample can be reproduced. |
| 2. Match | Calls and notes are linked to deals by deal ID, then by account name (abbreviations expanded). Only exact matches skip a human check. |
| 3. Code | Claude reads each document and writes open codes: short labels grounded in verbatim quotes. There is no preset tag list. Every quote is checked word for word against the source. |
| 4. Theme | Codes across deals are grouped into themes, and each theme becomes a testable claim. |
| 5. Reconstruct | For each deal, the CRM's version is compared with what the calls and notes say about outcome, competitors and loss stage. |
| 6. Review | Contradictions, competitors missing from the CRM, and quotes that don't match the source go to a review queue. |
| 7. Claims | Each claim gets evidence, a confidence level with plain-language reasons, and 90% ranges. |
| 8. Export | A Markdown report, or print to PDF. |

## How confidence works

Confidence is counted from evidence. The model never rates its own certainty.

- **Per deal:** *strong* means two or more source types agree. *Moderate* means a call says it and the other sources are silent. *Weak* means only the CRM or a single note says it. *Contested* means sources contradict each other, and the item goes to review.
- **Per claim:** *High*, *Medium* or *Low*, based on supporting deals, how many of them have strong evidence, counter-examples, the number of source types, and whether a person has checked it. **High always requires a person to check it.**
- **Rates:** every percentage has a 90% Wilson interval. When the CRM's win rate and the evidenced win rate overlap, Tribunal says the gap isn't proven and estimates how many deals would settle it.

## Run it locally

```bash
pip install -r requirements.txt
export ANTHROPIC_API_KEY=sk-ant-...     # optional: without it, the demo analyst runs
python app.py                            # http://localhost:5000
```

Click **Load sample company** to try it without real data.

## Run it on Replit

1. Put this folder in the repo as `tribunal/`, then import the repo into Replit and open the `tribunal` folder as the app root. Alternatively, create a new Python Repl and upload this folder.
2. Add secrets as needed: `ANTHROPIC_API_KEY` for Claude, `SESSION_SECRET` (any long random string), and optionally `TRIBUNAL_MODEL`.
3. Press **Run**. To deploy, use **Reserved VM**, or Autoscale with max instances set to 1. The app keeps state in one SQLite file, so it must run as a single instance.

**Public demo:** set `TRIBUNAL_PUBLIC=1` on the deployment. Uploads are disabled, every visitor gets their own copy of the sample company, and it always uses the demo analyst, so there's no API cost. Never put real customer data on a public deployment.

## Environment variables

| Variable | Default | Purpose |
| --- | --- | --- |
| `ANTHROPIC_API_KEY` | unset | Turns on Claude. Without it, the demo analyst is used. |
| `TRIBUNAL_MODEL` | `claude-opus-5-5` | Claude model ID for coding and theming. |
| `TRIBUNAL_PUBLIC` | unset | `1` turns on public demo mode: sample only, no uploads. |
| `SESSION_SECRET` | random per start | Signs session cookies. Set it on deployments. |
| `TRIBUNAL_DB` | `data/tribunal.db` | Where the SQLite file lives. |
| `PORT` | `5000` | Web port. |

## Input formats

- **CRM export (CSV):** column names are detected flexibly, for example *Opportunity ID / Deal ID*, *Account Name*, *Stage*, *Amount*, *Close Date*, *Owner*, *Competitor* (comma- or semicolon-separated), and *Loss Reason*.
- **Transcripts:** `.txt` or `.vtt`, one file per call. Optional header lines `Deal:`, `Account:` and `Date:` improve matching. Lines like `[mm:ss] Speaker: text` keep timestamps on quotes.
- **Field notes:** a CSV with *Deal ID*, *Account*, *Author*, *Date* and *Note* columns, or `.txt`/`.md` files with the same header lines as transcripts.

## The demo analyst

When no API key is set, and always in public mode, a transparent rule-based analyst stands in for Claude. It's tuned to the sample company and labelled on every screen. The pipeline, scoring, review queue and screens are the same as with Claude.

## Tests

```bash
python -m pytest -q tests/test_tribunal.py   # 17 tests, includes the full loop on the sample company
python -m tests.smoke 1                     # prints claims and headline for a sample run
```

The sample company (Parsely, with competitors Docufy, ClaimStack and Inkwell AI) is fictional. The tests check that Tribunal finds the patterns planted in it: competitors under-recorded in the CRM, stale "open" deals, POCs failing on legacy systems (with one counter-example), reseller undercutting, and early solutions engineer involvement in wins.

## Privacy

Uploaded data stays in the app's SQLite file and goes only to the Claude API. It is never written to the repo (`data/` is git-ignored). **Delete project** removes everything for that project.

## Roadmap (v2)

- Invite reviewers by link. Reviewers can challenge a claim with a reason and evidence, and every challenge and its resolution is logged. The data model already stores claim history.
- Re-check a challenged claim against new evidence.
- Live Salesforce (opportunities, competitors, stage history) and Gong (calls, transcripts, CRM links) connections.
- A shareable read-only report link.
